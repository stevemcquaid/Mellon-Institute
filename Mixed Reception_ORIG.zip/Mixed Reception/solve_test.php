<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
<head>
<title>
Mixed Reception Solved Case Report
</title>

<link rel=StyleSheet href="includes/modern.css" type="text/css">

</head>

<center>
<table width="701" cellpadding="0" cellspacing="0">
	<tr>
	<td class="mixed"><img src="images/banner.jpg" alt="Mixed Reception"></td>
	</tr> 

	<tr>
	<td class="mixed">
	<ul>
	<font size="+2"><b>Case Report:</b></font>
	<p>

	Instructions:  You must fill out all of the sections to solve the case.  
	Please be as descriptive as possible, using complete sentences, and proper grammar.  In section 2, 
	check all persons you think are guilty.  When you are finished filling out the report, 
	click the 'submit' button.</p>
	
	<P align=center>
     		<form action="submit.php" method="POST">
	<table  align=center border="1" cellpadding="9" cellspacing="2">
	<tr><td>
	<br><table cellpadding="3" cellspacing="3">
		<tr>
			<td class="mixed"><b>Name:</b></td>
			<td><input name="name" size="30"></td>
			<td class="mixed"><b>&nbsp;&nbsp;&nbsp;&nbsp;Email:</b></td>
			<td><input name="email" size="30"></td>
		</tr>
		<tr>
			<td class="mixed"><b>School:</b></td>
			<td><input name="school" size="30"></td>
			<td class="mixed"><b>&nbsp;&nbsp;&nbsp;&nbsp;Teacher's name:</b>
			<td><input name="instructor" size="30"></td>
		</tr></table></p>
	<br>
	<p><b>[Part 1 - Evidence] </b></p>
	<ul>
	<p>An unknown substance with a molecular weight of 
	765.82 was present in Nelson's blood.  What is this substance and how did it get 
	into his blood? </p>
	<ul><p>
	<textarea name="unknown_sub" rows="6" cols="69"></textarea></p></ul>
	
	<p>The coroner's report indicates that Nelson died from an allergic reaction, 
	yet he was taking a drug for this. Can you explain why he would still die from peanuts? </p>
	<ul><p>
	<textarea name="whypeanut_killed" rows="6" cols="69"></textarea></p></ul>
	
	
	<p>Was any of the evidence found at the crime scene important for your case? Why or why not?</p>
	<ul><p>
	<textarea name="crimescene_evid" rows="6" cols="69"></textarea></p></ul>
	</ul>
	<br>
	<p><b>[Part 2 - Suspects] </b>
	<ul>
	<p>The person(s) responsible for Nelson's death are:
	<ul><P>
          <input type="checkbox" name="suspect" value="DrYervin">Dr. Yervin<br>
          <input type="checkbox" name="suspect" value="Sam">Sam<br>
          <input type="checkbox" name="suspect" value="Joanna">Joanna</a><br>
          <input type="checkbox" name="suspect" value="Vince">Vince</a><br>
          <input type="checkbox" name="suspect" value="Nelson">Nelson (Suicide)</a><br>
	</p>
	</ul></ul><br>
	<p><b>[Part 3 - Method &amp; Motive] </b>
	<ul>
	<p>How was this crime committed? </p>
	<ul><p>
	<textarea name="how" rows="6" cols="69"></textarea></p></ul>
	
	<p>What possible motives are there for this action.</p>
	<ul><p>
	<textarea name="motive" rows="6" cols="69"></textarea></p></ul>
	
	
	</td></tr></table></p>
	<p>
	Click the 'Submit' button below to send your report to Head Quarters. We will review
	the details of your this case and report back to you in a few days. 
        <p><input type=submit value="Submit">&nbsp;&nbsp;<input type=reset value="Reset">
      </form>
	</ul></ul>
 	   </td>
 	 </tr>

	<tr>
	<td class="mixed"><img src="images/footer.jpg" alt="Mixed Reception Footer">
	</td>
	</tr>
</table>
  